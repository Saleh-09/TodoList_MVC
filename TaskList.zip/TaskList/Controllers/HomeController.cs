using Azure.Core.Extensions;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TaskList.Data;
using TaskList.Models;

namespace TaskList.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        //[HttpPost]
        //public IActionResult Index(TodoItem todoItem)
        //{
        //    _context.TodoItems.Add(todoItem);
        //    _context.SaveChanges();
        //    return View("Index",todoItem);
        //}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index([Bind("Title")] TodoItem todoItem)
        {
            if (ModelState.IsValid)
            {
                _context.Add(todoItem);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(todoItem);
        }

        public IActionResult AllTasks() 
        {
            var todos=_context.TodoItems.ToList();
            return View(todos);
        }
        


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var taskItem = await _context.TodoItems.FindAsync(id);
            if (taskItem == null)
            {
                return NotFound();
            }
            _context.TodoItems.Remove(taskItem);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }


    }
}
